<!DOCTYPE html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en-US" prefix="og: http://ogp.me/ns#"><![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang="en-US" prefix="og: http://ogp.me/ns#"><![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang="en-US" prefix="og: http://ogp.me/ns#"><![endif]-->
<!--[if IE 9]>
<html class="no-js lt-ie10" lang="en-US" prefix="og: http://ogp.me/ns#"><![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js" lang="en-US" prefix="og: http://ogp.me/ns#">
<!--<![endif]-->
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE"/>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="https://medimodo.com/xmlrpc.php">

	<!-- Fav and touch icons -->
			<link rel="shortcut icon" href="https://medimodo.com/wp-content/uploads/2017/02/medimodo-icon-16-transparent-lighter.png">
					
	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	<script src="https://medimodo.com/wp-content/themes/kleo/assets/js/html5shiv.js"></script>
	<![endif]-->

	<!--[if IE 7]>
	<link rel="stylesheet" href="https://medimodo.com/wp-content/themes/kleo/assets/css/fontello-ie7.css">
	<![endif]-->

	
	<title>Page not found - Medimodo</title>

<!-- This site is optimized with the Yoast SEO plugin v5.3.3 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found - Medimodo" />
<meta property="og:site_name" content="Medimodo" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="Page not found - Medimodo" />
<meta name="twitter:site" content="@MediModo" />
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"WebSite","@id":"#website","url":"https:\/\/medimodo.com\/","name":"MediModo","potentialAction":{"@type":"SearchAction","target":"https:\/\/medimodo.com\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"Organization","url":false,"sameAs":["https:\/\/www.facebook.com\/medimodoapp","https:\/\/www.linkedin.com\/company\/medimodo","https:\/\/twitter.com\/MediModo"],"@id":"#organization","name":"MediModo","logo":"https:\/\/medimodo.com\/wp-content\/uploads\/2017\/02\/cropped-medimodo-icon-1024-1024-transparent.png"}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//s0.wp.com' />
<link rel='dns-prefetch' href='//secure.gravatar.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Medimodo &raquo; Feed" href="https://medimodo.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Medimodo &raquo; Comments Feed" href="https://medimodo.com/comments/feed/" />
<!-- This site uses the Google Analytics by MonsterInsights plugin v6.2.2 - Using Analytics tracking - https://www.monsterinsights.com/ -->
<script type="text/javascript" data-cfasync="false">
		var disableStr = 'ga-disable-UA-98995949-1';

	/* Function to detect opted out users */
	function __gaTrackerIsOptedOut() {
		return document.cookie.indexOf(disableStr + '=true') > -1;
	}

	/* Disable tracking if the opt-out cookie exists. */
	if ( __gaTrackerIsOptedOut() ) {
		window[disableStr] = true;
	}

	/* Opt-out function */
	function __gaTrackerOptout() {
	  document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
	  window[disableStr] = true;
	}
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');

	__gaTracker('create', 'UA-98995949-1', 'auto');
	__gaTracker('set', 'forceSSL', true);
	__gaTracker('require', 'displayfeatures');
	__gaTracker('require', 'linkid', 'linkid.js');
	__gaTracker('send','pageview','/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer);
</script>
<!-- / Google Analytics by MonsterInsights -->
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/medimodo.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.8.1"}};
			!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,56826,8203,55356,56819),0,0),c=j.toDataURL(),b===c&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55358,56794,8205,9794,65039),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55358,56794,8203,9794,65039),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='simple-payments-css'  href='https://medimodo.com/wp-content/plugins/jetpack/modules/simple-payments/simple-payments.css?ver=4.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://medimodo.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.9' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='https://medimodo.com/wp-content/themes/kleo/assets/css/bootstrap.min.css?ver=4.2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kleo-app-css'  href='https://medimodo.com/wp-content/themes/kleo/assets/css/app.min.css?ver=4.2.3' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='https://medimodo.com/wp-content/themes/kleo/assets/js/plugins/magnific-popup/magnific.css?ver=4.2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kleo-fonts-css'  href='https://medimodo.com/wp-content/themes/kleo-child/assets/css/fontello.css?ver=4.2.3' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css'  href='https://medimodo.com/wp-includes/js/mediaelement/mediaelementplayer.min.css?ver=2.22.0' type='text/css' media='all' />
<link rel='stylesheet' id='kleo-google-fonts-css'  href='//fonts.googleapis.com/css?family=Roboto+Condensed%3A300%7COpen+Sans%3A400&#038;ver=4.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='kleo-colors-css'  href='https://medimodo.com/wp-content/uploads/custom_styles/dynamic.css?ver=4.2.3.1494201464' type='text/css' media='all' />
<link rel='stylesheet' id='kleo-plugins-css'  href='https://medimodo.com/wp-content/themes/kleo/assets/css/plugins.min.css?ver=4.2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kleo-style-css'  href='https://medimodo.com/wp-content/themes/kleo-child/style.css?ver=4.2.3' type='text/css' media='all' />
<link rel='stylesheet' id='jetpack_css-css'  href='https://medimodo.com/wp-content/plugins/jetpack/css/jetpack.css?ver=5.2.1' type='text/css' media='all' />
<script type='text/javascript' src='https://medimodo.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://medimodo.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var monsterinsights_frontend = {"js_events_tracking":"true","is_debug_mode":"false","download_extensions":"doc,exe,js,pdf,ppt,tgz,zip,xls","inbound_paths":"","home_url":"https:\/\/medimodo.com","track_download_as":"event","internal_label":"int","hash_tracking":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='https://medimodo.com/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend.min.js?ver=6.2.2'></script>
<script type='text/javascript' src='https://medimodo.com/wp-content/themes/kleo/assets/js/modernizr.custom.46504.js?ver=4.2.3'></script>
<link rel='https://api.w.org/' href='https://medimodo.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://medimodo.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://medimodo.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.8.1" />
<!-- Start Drift By WP-Plugin: Drift -->
<!-- Start of Async Drift Code -->
<script>
!function() {
  var t;
  if (t = window.driftt = window.drift = window.driftt || [], !t.init) return t.invoked ? void (window.console && console.error && console.error("Drift snippet included twice.")) : (t.invoked = !0, 
  t.methods = [ "identify", "config", "track", "reset", "debug", "show", "ping", "page", "hide", "off", "on" ], 
  t.factory = function(e) {
    return function() {
      var n;
      return n = Array.prototype.slice.call(arguments), n.unshift(e), t.push(n), t;
    };
  }, t.methods.forEach(function(e) {
    t[e] = t.factory(e);
  }), t.load = function(t) {
    var e, n, o, i;
    e = 3e5, i = Math.ceil(new Date() / e) * e, o = document.createElement("script"), 
    o.type = "text/javascript", o.async = !0, o.crossorigin = "anonymous", o.src = "https://js.driftt.com/include/" + i + "/" + t + ".js", 
    n = document.getElementsByTagName("script")[0], n.parentNode.insertBefore(o, n);
  });
}();
drift.SNIPPET_VERSION = '0.3.1';
drift.load('pt53uxxsr2gg');
</script>
<!-- End of Async Drift Code --><!-- end: Drift Code. -->

<link rel='dns-prefetch' href='//v0.wordpress.com'>
<link rel='dns-prefetch' href='//i0.wp.com'>
<link rel='dns-prefetch' href='//i1.wp.com'>
<link rel='dns-prefetch' href='//i2.wp.com'>
<style type='text/css'>img#wpstats{display:none}</style>	<meta name="mobile-web-app-capable" content="yes">
		<script type="text/javascript">
		/*
		 prevent dom flickering for elements hidden with js
		 */
		"use strict";

		document.documentElement.className += ' js-active ';
		document.documentElement.className += 'ontouchstart' in document.documentElement ? ' kleo-mobile ' : ' kleo-desktop ';

		var prefix = ['-webkit-', '-o-', '-moz-', '-ms-', ""];
		for (var i in prefix) {
			if (prefix[i] + 'transform' in document.documentElement.style) document.documentElement.className += " kleo-transform ";
		}
	</script>
			<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://medimodo.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="description" content="Optimizing Patient Outcomes With Data" />

<style>
#go-pricing-table-20295 .gw-go-col-wrap-0 .gw-go-header h3 {
    font-weight: bold !important;
    color: white;
}

#go-pricing-table-20295 .gw-go-col-wrap-1 .gw-go-header h3 {
    font-weight: bold !important;
    color: white;
}

#go-pricing-table-20295 .gw-go-col-wrap-2 .gw-go-header h3 {
    font-weight: bold !important;
    color: white;
}

#go-pricing-table-20301 .gw-go-col-wrap-0 .gw-go-header h3 {
    font-weight: bold !important;
    color: white;
}

#go-pricing-table-20301 .gw-go-col-wrap-1 .gw-go-header h3 {
    font-weight: bold !important;
    color: white;
}

#go-pricing-table-20301 .gw-go-col-wrap-2 .gw-go-header h3 {
    font-weight: bold !important;
    color: white;
}

</style>
<link rel="icon" href="https://i1.wp.com/medimodo.com/wp-content/uploads/2017/02/cropped-medimodo-icon-1024-transparent-vertical.png?fit=32%2C32&#038;ssl=1" sizes="32x32" />
<link rel="icon" href="https://i1.wp.com/medimodo.com/wp-content/uploads/2017/02/cropped-medimodo-icon-1024-transparent-vertical.png?fit=192%2C192&#038;ssl=1" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://i1.wp.com/medimodo.com/wp-content/uploads/2017/02/cropped-medimodo-icon-1024-transparent-vertical.png?fit=180%2C180&#038;ssl=1" />
<meta name="msapplication-TileImage" content="https://i1.wp.com/medimodo.com/wp-content/uploads/2017/02/cropped-medimodo-icon-1024-transparent-vertical.png?fit=270%2C270&#038;ssl=1" />
			<style type="text/css" id="wp-custom-css">
				/*
You can add your own CSS here.

Click the help icon above to learn more.
*/
.contactForm{
  background-color:white;
  color:grey;}

.panel{

background-color:#dd1f1f!important;
border:none;
}
.accordion-toggle{
color:white!important;
font-size: 110%;
font-family: "Roboto Condensed";
}
span.icon-closed.icon-users{
color:white!important;
font-size:1.5em;
}			</style>
		<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>


<body class="error404 kleo-navbar-fixed navbar-resize wpb-js-composer js-comp-ver-5.2.1 vc_responsive" itemscope itemtype="http://schema.org/WebPage">


<!-- PAGE LAYOUT
================================================ -->
<!--Attributes-->
<div class="kleo-page">

	<!-- HEADER SECTION
	================================================ -->
	
<div id="header" class="header-color">

	<div class="navbar" role="navigation">

		
			<!--Attributes-->
			<!--class = social-header inverse-->
			<div class="social-header header-color">
				<div class="container">
					<div class="top-bar">

												<div id="top-social" class="col-xs-12 col-sm-5 no-padd">
							<ul class="kleo-social-icons"><li><a target="_blank" href="https://twitter.com/MediModo"><i class="icon-twitter"></i><div class="ts-text">Twitter</div></a></li><li><a target="_blank" href="https://www.facebook.com/medimodoapp/"><i class="icon-facebook"></i><div class="ts-text">Facebook</div></a></li><li><a target="_blank" href="https://www.linkedin.com/company-beta/16241777"><i class="icon-linkedin"></i><div class="ts-text">Linkedin</div></a></li></ul>						</div>

						
					</div><!--end top-bar-->
				</div>
			</div>

		
				<div class="kleo-main-header header-normal">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<div class="kleo-mobile-switch">

												<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>

					</div>

					<div class="kleo-mobile-icons">

						
					</div>

					<strong class="logo">
						<a href="https://medimodo.com">

							
								Medimodo
							
						</a>
					</strong>
				</div>

				

				
				<!-- Collect the nav links, forms, and other content for toggling -->
				
				
				

			</div><!--end container-->
		</div>
	</div>

</div><!--end header-->

	<!-- MAIN SECTION
	================================================ -->
	<div id="main">



<section class='container-wrap main-title alternate-color  border-bottom'><div class='container'><h1 class="page-title">Error 404 - Page not found</h1><div class='breadcrumb-extra'>
		<div class="kleo_framework breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><span typeof="v:Breadcrumb"><a rel="v:url" property="v:title" href="https://medimodo.com" title="Medimodo" >Home</a></span>
			 <span class="sep"> </span> <span class="active">404 Not Found</span>
		</div><p class="page-info"> <i class="icon-mail-alt"></i> info@quantimo.do</p></div></div></section>

<section class="container-wrap main-color">
	<div id="main-container" class="container">
		<div class="row"> 
			<div class="template-page col-sm-12 tpl-no text-center">
				<div class="wrap-content">
					
				

<div class="row">
	<div class="col-sm-12">
			<p>It looks like nothing was found at this location. Maybe try a search?</p>
	</div>
</div>

<div class="row">
	<div class="col-sm-6 col-sm-offset-3 search-404">
			<form role="search" method="get" id="searchform" action="https://medimodo.com/">
	
	<div class="input-group">
		<input name="s" id="s" autocomplete="off" type="text" class="ajax_s form-control input-sm" value="">
		<span class="input-group-btn">
            <input type="submit" value="Search" id="searchsubmit" class="button">
		</span>
	</div>

</form>	</div>
</div>

<br><br><br>


				
				</div><!--end wrap-content-->
			</div><!--end main-page-template-->
						</div><!--end .row-->		</div><!--end .container-->
  
</section>
<!--END MAIN SECTION-->

			
		</div><!-- #main -->

		
<div id="footer" class="footer-color border-top">
	<div class="container">
		<div class="template-page tpl-no">
			<div class="wrap-content">
				<div class="row">
					<div class="col-sm-3">
						<div id="footer-sidebar-1" class="footer-sidebar widget-area" role="complementary">
							<div id="nav_menu-4" class="widget widget_nav_menu"><div class="menu-legal-container"><ul id="menu-legal" class="menu"><li id="menu-item-8819" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8819"><a href="https://medimodo.com/terms-of-service/">Terms of Service</a></li>
<li id="menu-item-8820" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8820"><a href="https://medimodo.com/privacy-policy/">Privacy Policy</a></li>
</ul></div></div>						</div>
					</div>
					<div class="col-sm-3">
						<div id="footer-sidebar-2" class="footer-sidebar widget-area" role="complementary">
													</div>
					</div>
					<div class="col-sm-3">
						<div id="footer-sidebar-3" class="footer-sidebar widget-area" role="complementary">
								
						</div>
					</div>
					<div class="col-sm-3">
						<div id="footer-sidebar-4" class="footer-sidebar widget-area" role="complementary">
													</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!-- #footer -->
	
				
		<!-- SOCKET SECTION
		================================================ -->

		<div id="socket" class="socket-color">
			<div class="container">
				<div class="template-page tpl-no col-xs-12 col-sm-12">
					<div class="wrap-content">

						<div class="row">
							<div class="col-sm-12">
								<div class="gap-10"></div>
							</div><!--end widget-->

							<div class="col-sm-12">
								<p style="text-align: center;"><strong>©2017 MediModo</strong> Optimizing Patient Outcomes with the Power of Data</p>
<p style="text-align: center;">167 Glenwood Dr. in beautiful Glen Carbon, IL</p>							</div>
							
							<div class="col-sm-12">
								<div class="gap-10"></div>
							</div><!--end widget-->
						</div><!--end row-->

					</div><!--end wrap-content-->
				</div><!--end template-page-->
			</div><!--end container-->
		</div><!--end footer-->
	</div><!-- #page -->

    
	<!-- Analytics -->
	<script type="text/javascript">
  function recordOutboundLink(link, category, action) {
    try {
      _gaq.push(['_trackEvent', category , action ]);
      setTimeout('document.location = "' + link.href + '"', 100)
    }catch(err){}
  }
</script>
		<div style="display:none">
	</div>
<!-- Modal Login form -->
<div id="kleo-login-modal" class="kleo-form-modal main-color mfp-hide">
    <div class="row">
        <div class="col-sm-12 text-center">

			
            <div class="kleo-pop-title-wrap main-color">
                <h3 class="kleo-pop-title">Log in with your credentials</h3>

				            </div>


			            <form action="https://medimodo.com/wp-login.php" id="login_form" name="login_form" method="post"
                  class="kleo-form-signin">
				<input type="hidden" id="security" name="security" value="ed87a117f2" /><input type="hidden" name="_wp_http_referer" value="/privacy-policy/linkid.js" />                <input type="text" id="username" autofocus required name="log" class="form-control" value=""
                       placeholder="Username">
                <input type="password" id="password" required value="" name="pwd" class="form-control"
                       placeholder="Password">
                <div id="kleo-login-result"></div>
                <button class="btn btn-lg btn-default btn-block"
                        type="submit">Sign in</button>
                <label class="checkbox pull-left">
                    <input id="rememberme" name="rememberme" type="checkbox"
                           value="forever"> Remember me                </label>
                <a href="#kleo-lostpass-modal"
                   class="kleo-show-lostpass kleo-other-action pull-right">Lost your password?</a>
                <span class="clearfix"></span>

				
            </form>

        </div>
    </div>
</div><!-- END Modal Login form -->


<!-- Modal Lost Password form -->
<div id="kleo-lostpass-modal" class="kleo-form-modal main-color mfp-hide">
    <div class="row">
        <div class="col-sm-12 text-center">
            <div class="kleo-pop-title-wrap alternate-color">
                <h3 class="kleo-pop-title">Forgot your details?</h3>
            </div>

			
            <form id="forgot_form" name="forgot_form" action="" method="post" class="kleo-form-signin">
				<input type="hidden" id="security" name="security" value="ed87a117f2" /><input type="hidden" name="_wp_http_referer" value="/privacy-policy/linkid.js" />                <input type="text" id="forgot-email" autofocus required name="user_login" class="form-control"
                       placeholder="Username or Email">
                <div id="kleo-lost-result"></div>
                <button class="btn btn-lg btn-default btn-block"
                        type="submit">Reset Password</button>
                <a href="#kleo-login-modal"
                   class="kleo-show-login kleo-other-action pull-right">I remember my details</a>
                <span class="clearfix"></span>
            </form>

        </div>
    </div>
</div><!-- END Modal Lost Password form -->


<script type='text/javascript' src='https://medimodo.com/wp-content/plugins/jetpack/modules/photon/photon.js?ver=20130122'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/medimodo.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}}};
/* ]]> */
</script>
<script type='text/javascript' src='https://medimodo.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.9'></script>
<script type='text/javascript' src='https://s0.wp.com/wp-content/js/devicepx-jetpack.js?ver=201735'></script>
<script type='text/javascript' src='https://secure.gravatar.com/js/gprofiles.js?ver=2017Augaa'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var WPGroHo = {"my_hash":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://medimodo.com/wp-content/plugins/jetpack/modules/wpgroho.js?ver=4.8.1'></script>
<script type='text/javascript' src='https://medimodo.com/wp-content/themes/kleo/assets/js/bootstrap.min.js?ver=4.2.3'></script>
<script type='text/javascript' src='https://medimodo.com/wp-content/plugins/js_composer/assets/lib/waypoints/waypoints.min.js?ver=5.2.1'></script>
<script type='text/javascript' src='https://medimodo.com/wp-content/themes/kleo/assets/js/plugins/magnific-popup/magnific.min.js?ver=4.2.3'></script>
<script type='text/javascript' src='https://medimodo.com/wp-content/themes/kleo/assets/js/plugins/carouFredSel/jquery.carouFredSel-6.2.0-packed.js?ver=4.2.3'></script>
<script type='text/javascript' src='https://medimodo.com/wp-content/themes/kleo/assets/js/plugins/carouFredSel/helper-plugins/jquery.touchSwipe.min.js?ver=4.2.3'></script>
<script type='text/javascript' src='https://medimodo.com/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js?ver=5.2.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mejsL10n = {"language":"en-US","strings":{"Close":"Close","Fullscreen":"Fullscreen","Turn off Fullscreen":"Turn off Fullscreen","Go Fullscreen":"Go Fullscreen","Download File":"Download File","Download Video":"Download Video","Play":"Play","Pause":"Pause","Captions\/Subtitles":"Captions\/Subtitles","None":"None","Time Slider":"Time Slider","Skip back %1 seconds":"Skip back %1 seconds","Video Player":"Video Player","Audio Player":"Audio Player","Volume Slider":"Volume Slider","Mute Toggle":"Mute Toggle","Unmute":"Unmute","Mute":"Mute","Use Up\/Down Arrow keys to increase or decrease volume.":"Use Up\/Down Arrow keys to increase or decrease volume.","Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds."}};
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/"};
/* ]]> */
</script>
<script type='text/javascript' src='https://medimodo.com/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=2.22.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var kleoFramework = {"ajaxurl":"https:\/\/medimodo.com\/wp-admin\/admin-ajax.php","themeUrl":"https:\/\/medimodo.com\/wp-content\/themes\/kleo","loginUrl":"https:\/\/medimodo.com\/wp-login.php","goTop":"0","ajaxSearch":"0","alreadyLiked":"You already like this","logo":"","retinaLogo":"","headerHeight":"88","headerHeightScrolled":"0","headerTwoRowHeight":"88","headerTwoRowHeightScrolled":"0","headerResizeOffset":"","loadingmessage":"<i class=\"icon icon-spin5 animate-spin\"><\/i> Sending info, please wait...","DisableMagnificGallery":"0","flexMenuEnabled":"0","portfolioVideoHeight":"160"};
/* ]]> */
</script>
<script type='text/javascript' src='https://medimodo.com/wp-content/themes/kleo/assets/js/app.min.js?ver=4.2.3'></script>
<script type='text/javascript' src='https://medimodo.com/wp-includes/js/wp-embed.min.js?ver=4.8.1'></script>
<script type='text/javascript' src='https://stats.wp.com/e-201735.js' async defer></script>
<script type='text/javascript'>
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:5.2.1',blog:'59233458',post:'0',tz:'0',srv:'medimodo.com'} ]);
	_stq.push([ 'clickTrackerInit', '59233458', '0' ]);
</script>

</body>
</html>